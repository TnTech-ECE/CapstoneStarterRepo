let map;
let markers = []; // Array to store each drone's marker

// Fetch data from the Node.js server 
async function fetchDroneData() {
    try {
        const response = await fetch('http://10.104.130.17:3000/api/drone-data');
        console.log(response);

        if (!response.ok) {
            throw new Error('Failed to fetch data');
        }

        const data = await response.json();
        return data.length > 0 ? data : [];
    } catch (error) {
        console.error("Error fetching data:", error);
        return [];
    }
}

// Update map and table with the latest data
async function fetchAndDisplayData() {
    const droneData = await fetchDroneData();
    const showApprovedOnly = document.getElementById('toggleApproved').checked;

    // Filter the drones based on approval status if the toggle is checked
    const filteredData = showApprovedOnly ? droneData.filter(drone => drone.approved === 1) : droneData;

    // Clear previous markers from the map
    markers.forEach(marker => marker.setMap(null));
    markers = []; // Reset markers array

    // Place a marker for each drone in the filtered data
    filteredData.forEach(drone => {
        const position = { lat: parseFloat(drone.lat), lng: parseFloat(drone.lng) };

        // Create a marker for each drone
        const marker = new google.maps.Marker({
            map: map,
            position: position,
            title: `Drone ID: ${drone.id} - Speed: ${drone.speed} - Altitude: ${drone.drone_altitude}`,
        });

        // Add the marker to the array
        markers.push(marker);
    });

    // // Center map on the first drone's position if available, or a default position
    // if (filteredData.length > 0) {
    //     const firstPosition = { lat: parseFloat(filteredData[0].lat), lng: parseFloat(filteredData[0].lng) };
    //     map.setCenter(firstPosition);
    // } else {
    //     map.setCenter({ lat: 36.17532, lng: -85.50593 }); // Default center if no drone data
    //     alert("No approved drone data available.");
    // }

    // Populate the data table with all drone data or filtered data
    populateTable(filteredData);
}

// Function to fill the HTML table with data
function populateTable(data) {
    const tableBody = document.getElementById('table-body');
    tableBody.innerHTML = ""; // Clear existing rows

    if (data.length === 0) {
        const row = document.createElement('tr');
        row.innerHTML = `<td colspan="7">No data available</td>`;
        tableBody.appendChild(row);
    } else {
        data.forEach(drone => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${drone.id}</td>
                <td>${drone.lat}</td>
                <td>${drone.lng}</td>
                <td>${drone.speed}</td>
                <td>${drone.drone_altitude}</td>
                <td>${drone.timestamp}</td>
                <td><input type="checkbox" ${drone.approved === 1 ? 'checked' : ''}></td>
            `;
            tableBody.appendChild(row);

            const checkbox = row.querySelector('input[type="checkbox"]');
            checkbox.addEventListener('change', () => {
                updateApprovalStatus(drone.id, checkbox.checked ? 1 : 0);
            });
        });
    }
}

function updateApprovalStatus(id, approved) {
    fetch('http://10.104.130.17:3000/api/drone-update', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ id, approved }),
    })
        .then(response => response.text())
        .then(text => {
            const data = text ? JSON.parse(text) : { message: "No response data" };
            console.log(data.message);
        })
        .catch(error => {
            console.error('Error updating approval status:', error);
        });
}

// Initialize the Google Map
function initMap() {
    const position = { lat: 36.17532, lng: -85.50593 }; // Default position
    map = new google.maps.Map(document.getElementById('map'), {
        zoom: 16,
        center: position,
        mapTypeId: 'satellite',
    });

    // Fetch data every 10 seconds (10000ms)
    setInterval(fetchAndDisplayData, 10000);

    // Initial data fetch and display
    fetchAndDisplayData();
}



// Add event listener for the toggle checkbox
document.getElementById('toggleApproved').addEventListener('change', fetchAndDisplayData);

initMap();