const express = require('express');
const mysql = require('mysql2');
const fs = require('fs');
const path = require('path');
const cors = require('cors');

const app = express();
const port = 3000;

app.use(express.json());
app.use(cors());  // Allow all origins by default

// Set up database connection
const connection = mysql.createConnection({
  host: '10.104.130.17',
  user: 'root', // your database username
  password: 'tntech', // your database password
  database: 'RID', // your database name
});

// Connect to the database
connection.connect((err) => {
  if (err) {
    console.error('Error connecting to the database:', err.stack);
    return;
  }
  console.log('Connected to the database');
});

// Endpoint to fetch drone data
app.get('/api/drone-data', (req, res) => {
  const sql = 'SELECT id, drone_latitude AS lat, drone_longitude AS lng, speed, drone_altitude, timestamp, approved FROM drone_location ORDER BY timestamp DESC LIMIT 100';

  connection.query(sql, (err, results) => {
    if (err) {
      console.error('Error fetching data:', err);
      res.status(500).json({ error: 'Failed to fetch data' });
    } else {
      res.json(results);
    }
  });
});

// Endpoint to update drone approval status
app.post('/api/drone-update', (req, res) => {
  // Get the drone data from the request body
  let drone = req.body;
  console.log(drone); // Log the drone data to see the contents

  const { id, approved } = drone;  // Extract ID and approved value from the request body

  // Validate input
  if (!id || approved === undefined) {
    return res.status(400).json({ message: "Missing required fields: id and approved" });
  }

  // SQL query to update the approval status
  const query = 'UPDATE drone_location SET approved = ? WHERE id = ?';

  // Run the update query
  connection.query(query, [approved, id], (err, results) => {
    if (err) {
      console.error('Error updating drone approval:', err);
      return res.status(500).json({ message: "Error updating drone approval" });
    }

    if (results.affectedRows === 0) {
      return res.status(404).json({ message: "Drone not found" });
    }

    // Successfully updated approval status
    res.status(200).json({ message: `Drone approval status updated successfully ${id} ${approved}` });
  });
});

// Endpoint to fetch drone images
app.get('/api/drone-images/:droneId', (req, res) => {
  const droneId = req.params.droneId;
  const droneImageDir = path.join(__dirname, 'drone_images', droneId);  // Assuming images are stored in 'drone_images/{droneId}'

  // Check if the directory exists
  if (!fs.existsSync(droneImageDir)) {
    return res.status(404).json({ message: `No images found for drone ${droneId}` });
  }

  // Read the image files from the directory
  fs.readdir(droneImageDir, (err, files) => {
    if (err) {
      console.error('Error reading images directory:', err);
      return res.status(500).json({ message: 'Failed to read images directory' });
    }

    // Filter out non-image files (optional, depending on your file types)
    const imageFiles = files.filter(file => /\.(jpg|jpeg|png|gif)$/i.test(file));

    if (imageFiles.length === 0) {
      return res.status(404).json({ message: `No valid images found for drone ${droneId}` });
    }

    // Return the list of image file names
    res.json(imageFiles.map(file => ({
      url: `/drone-images/${droneId}/${file}`,
      fileName: file
    })));
  });
});

// Serve static files (like your HTML, CSS, JS)
app.use(express.static('public'));

// Serve image files directly
app.use('/drone-images', express.static(path.join(__dirname, 'drone_images')));

// Start the server
app.listen(port, () => {
  console.log(`Server running at http://10.104.130.17:${port}`);
});
